package org.republic.EmployeeManagementSystem.projection;

public class DepartmentNameDTO {

    private String name;

    public DepartmentNameDTO(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
