package org.republic.EmployeeManagementSystem.projection;

public interface EmployeeNameDTO {
    String getName();
}
